<template>
  <div class="Hasservice">
    <!--工人详情  -->
    <div class="work_list">
      <ul style="display:flex; justify-content:space-evenly;">
        <li
          v-for="(item,index) in work_list"
          :key="index"
          @click="workList(index,$event)"
          :class="{'work_active':work_active}"
        >
          {{item}}
          <i :class="triangle"></i>
        </li>
      </ul>
       <div class="name" v-show="nameshow">
        <ul>
          <li v-for="(item,index) in datamenu" :key="index">{{item.name}}</li>
        </ul>
        <div style="text-align:center; padding:2px 0 10px 0 ;">
          <van-button
            type="default"
            style="width:225px;height:30px;background:#499ef0;color:#fff;line-height:30px;border-radius: 15px;"
          >确定</van-button>
        </div>
      </div>
      <div class="name" v-show="project">
        <ul>
          <li v-for="(item,index) in service" :key="index">{{item.project}}</li>
        </ul>
        <div style="text-align:center; padding:2px 0 10px 0 ;">
          <van-button
            type="default"
            style="width:225px;height:30px;background:#499ef0;color:#fff;line-height:30px;border-radius: 15px;"
          >确定</van-button>
        </div>
      </div>
    </div>
    <div class="Person_class" style="margin-top:5px;">
      <div class="Person_classleft">
        <h2>276
          <span>单</span>
        </h2>
        <p>已服务工单总数</p>
      </div>
      <div class="Person_classleft">
        <h2>1000.00
          <span>元</span>
        </h2>
        <p>可服务工单总金额</p>
      </div>
    </div>
    <div class="Hasservice_list">
      <div class="Hasservice_listher">
        <h2>
          <span></span>疏通服务
        </h2>
        <van-rate v-model="value" :size="14" :count="5" color="#ffa800"/>
      </div>
      <div class="Hasservice_listcen">
        <p>姓名：李某某</p>
        <p>电话：184XXXX9826</p>
        <p>地址：四川省成都市成华区万科华茂1204号</p>
        <p>接单时间：2018年11月16日 15:35:49</p>
        <p>完成时间：2018年11月16日 16:35:49</p>
      </div>
      <div class="Hasservice_listpic">
        <p>服务价格：&emsp;
          <span>&yen;90.00</span>
        </p>
      </div>
    </div>
    <div class="Hasservice_list">
      <div class="Hasservice_listher">
        <h2>
          <span></span>疏通服务
        </h2>
        <van-rate v-model="value" :size="14" :count="5" color="#ffa800"/>
      </div>
      <div class="Hasservice_listcen">
        <p>姓名：李某某</p>
        <p>电话：184XXXX9826</p>
        <p>地址：四川省成都市成华区万科华茂1204号</p>
        <p>接单时间：2018年11月16日 15:35:49</p>
        <p>完成时间：2018年11月16日 16:35:49</p>
      </div>
      <div class="Hasservice_listpic">
        <p>服务价格：&emsp;
          <span>&yen;90.00</span>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Workdateils",
  data() {
    return {
        nameshow: false,
      project: false,
      work_active: false,
      triangle: "el-icon-caret-bottom",
      work_list: ["工人姓名", "服务项目"],
      value: 5,
      active: 0, //索引
      tab: [
        { data: "今日" },
        { data: "近7日" },
        { data: "近30日" },
        { data: "全部" }
      ],
      datamenu: [
        { name: "全部工人" },
        { name: "杨师傅" },
        { name: "王师傅" },
        { name: "冯师傅" },
        { name: "李师傅" },
        { name: "张师傅" },
        { name: "廖师傅" }
      ],
      service: [
        { project: "全部服务" },
        { project: "开锁服务" },
        { project: "空调维修" },
        { project: "电视维修" },
        { project: "热水器维修" },
        { project: "疏通服务" }
      ]
    };
  },
  methods: {
    showtab(index) {
      this.active = index;
    },
    workList(index, e) {
      if (index == 0) {
        if (!e.target.className) {
          this.nameshow = true;
          this.project = false;
        } else {
          this.project = true;
          this.nameshow = false;
        }
      }
      if (index == 1) {
        if (!e.target.className) {
          this.project = true;
          this.nameshow = false;
        } else {
          this.nameshow = true;
          this.project = false;
        }
      }

      if (!e.target.className) {
        e.target.className = "work_active"; //切换按钮样式
        this.triangle = "el-icon-caret-bottom";
      } else {
        e.target.className = ""; //切换按钮样式
        this.triangle = "el-icon-caret-top";
        this.nameshow = false;
      }
    }
  }
};
</script>
<style>
 .name {
  text-align: left;
  line-height: 33px;
}
.name ul {
  background: #f5f5f5;
}
.name ul li {
  border-bottom: 1px solid #c7c7c7;
  padding-left: 28px;
  color: #333;
}
 .name ul li:last-child {
  border: 0;
}
 .work_list {
  background: #fff;
  margin-bottom: 5px;
}
 .work_list ul li i {
  font-size: 12px;
}
 .work_list ul li {
  margin: 8px 0;
}
.Hasservice {
  background: #f5f5f5;
  height: 100%;
}
.Hasservice_header {
  background: #fff;
}
.Hasservice_header > h2 {
  font-weight: bold;
  color: #ff8431;
  font-size: 24px;
  font-family: PingFangSC-Regular;
  padding: 20px 0 13px 0;
}
.Hasservice_header > h2 > span {
  font-size: 12px;
}
.Hasservice_header > p {
  font-size: 14px;
  padding-bottom: 20px;
}
.Hasservice_tab > ul {
  display: flex;
  height: 25px;
  border: 1px solid #499ef0;
  border-radius: 25px;
}
.Hasservice_tab {
  padding: 10px 10px 0 10px;
  background: #fff;
  margin-top: 5px;
}
.Hasservice_tab > ul > li {
  flex-grow: 1;
  line-height: 25px;
  color: #499ef0;
  font-size: 13px;
  font-family: PingFangSC-Regular;
}
.Hasservice_tab > ul > li:nth-child(1) {
  border-radius: 25px 0 0 25px;
}
.Hasservice_tab > ul > li:nth-child(4) {
  border-radius: 0 25px 25px 0;
}
.Hasservice_tab > ul > li:nth-child(2) {
  border-left: 1px solid #499ef0;
  border-right: 1px solid #499ef0;
}
.Hasservice_tab > ul > li:nth-child(3) {
  border-right: 1px solid #499ef0;
}
.Hasservice_fl {
  display: flex;
  justify-content: space-around;
  font-size: 12px;
  color: #333;
  padding: 20px 0;
}
.Hasservice_fl .Hasservice_dat p {
  padding-bottom: 10px;
}
.Hasservice_fl .Hasservice_dat span {
  font-size: 14px;
  color: #499ef0;
}
.Hasservice_list {
  width: 355px;
  background: #fff;
  margin: 10px;
  border-radius: 10px;
}
.Hasservice_listher {
  display: flex;
  justify-content: space-between;
  padding: 10px 10px 15px 10px;
}
.Hasservice_listher h2 {
  font-size: 14px;
  color: #499ef0;
  border-left: 3px solid #499ef0;
  padding-left: 13px;
  line-height: 15px;
}
.Hasservice_listcen {
  border-bottom: 1px solid #c7c7c7;
  padding-bottom: 10px;
  text-align: left;
  padding-left: 10px;
}
.Hasservice_listcen p {
  line-height: 20px;
}
.Hasservice_listpic {
  text-align: right;
  padding: 10px 10px 10px 0;
  font-size: 12px;
}
.Hasservice_listpic span {
  font-size: 18px;
  color: #499ef0;
}
.active {
  background: #499ef0;
  color: #fff !important;
}
.Person_class {
  display: flex;
  justify-content: space-around;
  background: #fff;
  margin-top: 11px;
}
.Person_class .Person_classleft h2 {
  color: #ff8431;
  font-size: 24px;
  margin: 18px 0 13px 0;
}
.Person_class .Person_classleft h2 span {
  color: #ff8431;
  font-size: 12px;
}
.Person_class .Person_classleft p {
  font-size: 14px;
  margin-bottom: 18px;
}
.work_active {
  color: #499ef0 !important;
}

/*#box .el-date-editor.el-input__inner {*/
  /*width: 100%;*/
/*}*/
/*#box .el-select .el-input.is-focus .el-input__inner {*/
  /*border: 0;*/
/*}*/
/*#box .el-select .el-input__inner:focus {*/
  /*border: 0;*/
/*}*/
/*#box .el-input__inner {*/
  /*border: 0 !important;*/
  /*text-align: center;*/
/*}*/
/*#box .el-select input::-webkit-input-placeholder {*/
  /*!* placeholder颜色  *!*/
  /*color: #333; !* placeholder字体大小  *!*/
  /*font-size: 14px; !* placeholder位置  *!*/
  /*text-align: center;*/
/*}*/
/*#box .el-select .el-input .el-select__caret {*/
  /*color: #333;*/
/*}*/
.el-select-dropdown {
  width: 100%;
  top: 28px !important;
  left: 0px !important ;
  border: 0;
}
</style>

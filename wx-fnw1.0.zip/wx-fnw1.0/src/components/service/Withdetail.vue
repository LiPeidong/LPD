<template>
  <div class="Withdetail">
   <!-- 提现明细 -->
   <h2>提现明细</h2>
   <div class="detail">
      <ul>
        <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
         <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
          <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
          <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
          <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
          <li>
          <p>提现明细</p>
          <p style="text-align:right;">- &yen; 1000.00</p>
          <p style="color:#878787;">2018.08.01</p>
        </li>
      </ul>
   </div>
  </div>
</template>
<script>
export default {
  name: 'Withdetail',
  data:{

  }
}
</script>

<style scoped>
.Withdetail>h2{font-size: 18px;background: #fff;padding: 12px 20px; font-weight: bold;text-align: left;}
.detail{background: #fff;text-align: left;margin-top: 5px;}
.detail>ul>li{border-bottom: 1px solid #c7c7c7;padding: 10px 20px;}
</style>

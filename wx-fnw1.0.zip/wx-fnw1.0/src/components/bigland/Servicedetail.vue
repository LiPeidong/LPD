<template>
  <div class="Withdetail">
   <!-- 服务明细 -->
   <h2>服务明细</h2>
   <div class="detail">
      <ul>
        <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
         <li>
          <p>开锁服务</p>
          <p style="text-align:right;">- &yen; 144.00</p>
          <p style="color:#878787;font-size:12px;">2018.08.01</p>
        </li>
        
      </ul>
   </div>
  </div>
</template>
<script>
export default {
  name: 'Servicedetail',
  data:{

  }
}
</script>

<style scoped>
.Withdetail{height: 100%;}
.Withdetail>h2{font-size: 18px;background: #fff;padding: 12px 20px; font-weight: bold;text-align: left;}
.detail{background: #fff;text-align: left;margin-top: 5px;height: 100%;}
.detail>ul>li{border-bottom: 1px solid #c7c7c7;padding: 10px 20px;}
</style>

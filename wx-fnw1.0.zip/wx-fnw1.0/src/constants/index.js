const BASE_URL = 'http://saas.funlifeday.com';//api是代理识别标识  https://saas.funlifeday.com
export default BASE_URL;

